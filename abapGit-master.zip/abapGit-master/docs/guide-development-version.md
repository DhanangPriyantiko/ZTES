---
title: Development version
category: setup
order: 30
---

Install the abapGit development version using abapGit, either via online or offline projects.
Recommend keeping the compiled report in a different package, so it can be used as fallback in case of syntax errors.