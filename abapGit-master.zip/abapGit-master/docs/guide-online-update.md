---
title: Keeping code up to date
category: online projects
order: 20
---

* Start ZABAPGIT, it will automatically compare local and remote code. If code is updated in the remote repository a "pull" link will appear

![](img/code_new.png)

* Click the "pull" link and it will update the local code

* After the update, no links should appear,

![](img/code_no_new.png)